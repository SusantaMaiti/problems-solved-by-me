let data= ["madhya pradesh", "west bengal", "goa", "bihar"]





export default data;